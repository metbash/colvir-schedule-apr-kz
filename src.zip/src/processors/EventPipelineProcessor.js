/**
 * ==========================================================
 * Colvir Schedule & APR Calculator (KZ)
 * Version: 4.0-dev5
 *
 * EventPipelineProcessor.js
 *
 * Единая точка прохождения событий расчета.
 * ==========================================================
 */

import BaseProcessor from "./BaseProcessor.js";
import GraceProcessor from "./GraceProcessor.js";
import RateChangeProcessor from "./RateChangeProcessor.js";

import { EventType } from "../core/Enums.js";

export default class EventPipelineProcessor extends BaseProcessor {

    constructor() {

        super();

        this.graceProcessor = new GraceProcessor();

        this.rateChangeProcessor =
            new RateChangeProcessor();

    }

    process(state) {

        return {

            graceType: this.graceProcessor.process(
                state
            ),

            effectiveRate: this.rateChangeProcessor.process(
                state
            ),

            rateChangeEvents: state.getDateReachedEvents(
                EventType.RATE_CHANGE
            ),

            manualAdjustmentEvents: state.getDateReachedEvents(
                EventType.MANUAL_ADJUSTMENT
            ),

            restructureEvents: state.getDateReachedEvents(
                EventType.RESTRUCTURE
            )

        };

    }

}